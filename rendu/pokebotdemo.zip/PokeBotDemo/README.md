#PokeBotDemo
[![Build Status](https://travis-ci.org/IUTInfoAix/PokeBotDemo.png?branch=master)](https://travis-ci.org/IUTInfoAix/PokeBotDemo/)

Bot pokemon de démonstration contruit en utilisant TwitterUserStreamEasy et Twitter4J. Pour le rendre fonctionnel,
il faut compléter le fichier `src/main/resource/twitter4j.properties` avec les clef que vous trouverez sur la page
https://dev.twitter.com/apps après avoir créé une application.
